#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"
#include "vm/page.h"
#include "vm/swap.h"
#include "vm/frame.h"

tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);
struct thread *get_child_process (int pid);

/* Project 2 : file sysytem */
int process_add_file (struct file *file);
struct file *process_get_file (int fd);
bool process_close_file (int fd);

/* Projcet 4 added. */
bool handle_mm_fault (struct vm_entry *);
bool expand_stack (void *);
bool verify_stack (void *, void *);
#endif /* userprog/process.h */
