#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <stdint.h>
#include <debug.h>
#include <list.h>
#include <hash.h>
#include "threads/palloc.h"
#include "threads/vaddr.h"

extern struct lock lru_list_lock;

/* Types of virtual pages */
enum vm_type
{
    VM_ANON,
    VM_BIN
};

/* Structure for page */
struct page
{
    void *kaddr;
    struct vm_entry *vme;
    struct thread *thread;
    struct list_elem lru;
};

struct vm_entry
{
    uint8_t type;

    void *vaddr;  //Virtual address
    bool writable;  //True : writable, False : unwritable
    bool is_loaded; //True if loaded on Physical memory
    bool holded;  //False : unwritable(temporary)
    struct file *file;  //file mapped
    
    size_t offset;
    size_t read_bytes;
    size_t zero_bytes;

    
    size_t swap_slot;
    /* Element for hash table */
    struct hash_elem elem;
};

void vm_init (struct hash *);
void vm_destroy (struct hash *);

struct vm_entry *find_vme (void *vaddr);
bool insert_vme (struct hash *, struct vm_entry *);
bool delete_vme (struct hash *, struct vm_entry *);

bool load_file (void *kaddr, struct vm_entry *);



#endif