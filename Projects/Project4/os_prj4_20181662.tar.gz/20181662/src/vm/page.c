#include "page.h"
#include "threads/vaddr.h"
#include "threads/thread.h"
#include "threads/malloc.h"
#include "vm/frame.h"
#include "vm/swap.h"
#include "userprog/pagedir.h"
#include "filesys/file.h"
#include "threads/interrupt.h"
#include <string.h>

/* Hash functions for vm hash table */
static unsigned vm_hash_func (const struct hash_elem *, void * UNUSED);
static bool vm_less_func (const struct hash_elem *, const struct hash_elem *, void * UNUSED);



void vm_init (struct hash *vm)
{
  ASSERT (vm != NULL);
  hash_init (vm, vm_hash_func, vm_less_func, NULL);
}

void vm_destroy (struct hash *vm)
{
  ASSERT (vm != NULL);
  hash_destroy(vm, NULL);
}

static unsigned
vm_hash_func (const struct hash_elem *e, void *aux UNUSED)
{
  ASSERT (e != NULL);
  return hash_int (hash_entry (e, struct vm_entry, elem)->vaddr);
}

static bool
vm_less_func (const struct hash_elem *a,
              const struct hash_elem *b, void *aux UNUSED)
{
  ASSERT (a != NULL);
  ASSERT (b != NULL);
  return hash_entry (a, struct vm_entry, elem)->vaddr
    < hash_entry (b, struct vm_entry, elem)->vaddr;
}



struct vm_entry *
find_vme (void *vaddr)
{
  struct hash *vm;
  struct vm_entry vme;
  struct hash_elem *elem;

  vm = &thread_current ()->vm;
  vme.vaddr = pg_round_down (vaddr);
  ASSERT (pg_ofs (vme.vaddr) == 0);
  elem = hash_find (vm, &vme.elem);
  return elem ? hash_entry (elem, struct vm_entry, elem) : NULL;
}

bool
insert_vme (struct hash *vm, struct vm_entry *vme)
{
  ASSERT (vm != NULL);
  ASSERT (vme != NULL);
  ASSERT (pg_ofs (vme->vaddr) == 0);

  vme->holded = false; 
  return hash_insert (vm, &(vme->elem)) == NULL;
}

bool
delete_vme (struct hash *vm, struct vm_entry *vme)
{
  ASSERT (vm != NULL);
  ASSERT (vme != NULL);
  if (!hash_delete (vm, &vme->elem))
    return false;
  free_page(pagedir_get_page(thread_current()->pagedir, vme->vaddr));
  
  free (vme);
  return true;
}


bool load_file (void *kaddr, struct vm_entry *vme)
{
  ASSERT (kaddr != NULL);
  ASSERT (vme != NULL);
  ASSERT (vme->type == VM_BIN);
  file_seek(vme->file, vme->offset);
  if(file_read (vme->file, kaddr, vme->read_bytes) != (int) vme->read_bytes)
  {
      return false;
  }

  memset (kaddr + vme->read_bytes, 0, vme->zero_bytes);
  return true;
}

