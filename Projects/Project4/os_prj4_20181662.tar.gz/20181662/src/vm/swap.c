#include "vm/swap.h"
#include "devices/block.h"
#include "vm/frame.h"
#include "vm/page.h"

const size_t BLOCK_PER_PAGE = PGSIZE / BLOCK_SECTOR_SIZE;

void swap_init()
{
    swap_bitmap = bitmap_create(8*1024);
}

void swap_in(size_t swap_index, void *kaddr)
{
    struct block *swap_disk = block_get_role(BLOCK_SWAP);
    if(bitmap_test(swap_bitmap, swap_index))
    {
        for(int i = 0; i < BLOCK_PER_PAGE; i++)
        {
            block_read(swap_disk, BLOCK_PER_PAGE * swap_index + i, BLOCK_SECTOR_SIZE * i + kaddr);
        }
        bitmap_reset(swap_bitmap, swap_index);
    }
}

size_t swap_out(void *kaddr)
{
    struct block *swap_disk = block_get_role(BLOCK_SWAP);
    
    size_t swap_index = bitmap_scan(swap_bitmap, 0, 1, false);
    if(BITMAP_ERROR != swap_index)
    {
        for(int i = 0; i < BLOCK_PER_PAGE; i++)
        {
            block_write(swap_disk, BLOCK_PER_PAGE * swap_index + i, BLOCK_SECTOR_SIZE * i + kaddr);
        }
        bitmap_set(swap_bitmap, swap_index, true);
    }
    return swap_index;
}