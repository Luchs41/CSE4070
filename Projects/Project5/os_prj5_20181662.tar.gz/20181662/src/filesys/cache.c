#include "filesys/cache.h"
#include "threads/palloc.h"
#include <string.h>

#define NUM_CACHE 64

struct buffer_cache_entry cache[NUM_CACHE];
struct lock buffer_cache_lock;
struct buffer_cache_entry *victim;

void buffer_cache_init (void) {
    lock_init(&buffer_cache_lock);
    for(int i = 0; i < NUM_CACHE; i++) {
        memset(&cache[i], 0, sizeof(struct buffer_cache_entry));
        lock_init(&cache[i].lock);
    }
    victim = cache;
}

void buffer_cache_terminate (void) {
    buffer_cache_flush_all();
}

bool buffer_cache_read(block_sector_t sector, void *buffer, off_t offset, int chunk_size, int sector_ofs) {
    struct buffer_cache_entry *target = buffer_cache_lookup(sector);
    if (target == NULL) {
        /* Cache miss */
        lock_acquire(&buffer_cache_lock);

        struct buffer_cache_entry *new = buffer_cache_select_victim();
        lock_acquire(&new->lock);
        
        new->valid_bit = true;
        new->dirty_bit = false;
        new->reference_bit = true;
        new->disk_sector = sector;
        
        block_read(fs_device, sector, new->buffer);

        memcpy(buffer + offset, new->buffer + sector_ofs, chunk_size);
        lock_release(&new->lock);
        lock_release(&buffer_cache_lock);
    }
    else {
        /* Cache Hit */
        lock_acquire(&target->lock);
        memcpy(buffer + offset, target->buffer + sector_ofs, chunk_size);
        target->reference_bit = true;
        lock_release(&target->lock);
    }
    return true;
}

bool buffer_cache_write (block_sector_t sector, void *buffer, off_t offset, int chunk_size, int sector_ofs) {
    struct buffer_cache_entry *target = buffer_cache_lookup(sector);
    if (target == NULL) {
        /* Cache miss */
        lock_acquire(&buffer_cache_lock);

        struct buffer_cache_entry *new = buffer_cache_select_victim();
        lock_acquire(&new->lock);
        
        new->valid_bit = true;
        new->dirty_bit = true;
        new->reference_bit = true;
        new->disk_sector = sector;
        
        block_read(fs_device, sector, new->buffer);

        memcpy(new->buffer + sector_ofs, buffer + offset, chunk_size);
        lock_release(&new->lock);
        lock_release(&buffer_cache_lock);
    }
    else {
        /* Cache Hit */
        lock_acquire(&target->lock);
        memcpy(target->buffer + sector_ofs, buffer + offset, chunk_size);
        target->reference_bit = true;
        target->dirty_bit = true;
        lock_release(&target->lock);
    }
    return true;
}

struct buffer_cache_entry *buffer_cache_lookup (block_sector_t sector) {
    lock_acquire(&buffer_cache_lock);
    int found = -1;
    for(int i = 0; i < NUM_CACHE; i++) {
        if(cache[i].valid_bit == true && cache[i].disk_sector == sector) {
            found = i;
            break;
        }
    }
    lock_release(&buffer_cache_lock);
    if(found >= 0 && found < NUM_CACHE) {
        return &cache[found];
    }
    else return NULL;
}

struct buffer_cache_entry *buffer_cache_select_victim (void){
    while(1) {
        if(victim == cache + NUM_CACHE) {
            victim = cache;
        }
        lock_acquire(&victim->lock);
        if(victim->valid_bit == false || victim->reference_bit == false) {
            struct buffer_cache_entry *target = victim;
            buffer_cache_flush_entry(target);
            lock_release(&victim->lock);
            victim++;
            return target;
        }
        victim->reference_bit = false;
        lock_release(&victim->lock);
        victim++;
    }
}

void buffer_cache_flush_entry (struct buffer_cache_entry *target) {
    if(target->valid_bit == true && target->dirty_bit == true) {
        block_write(fs_device, target->disk_sector, target->buffer);
        for(int i = 0; i < BLOCK_SECTOR_SIZE; i++) {
            target->buffer[i] = NULL;
        }
        target->dirty_bit = false;
    }
}
void buffer_cache_flush_all (void) {
    for(int i = 0; i < NUM_CACHE; i++) {
        lock_acquire(&cache[i].lock);
        buffer_cache_flush_entry(&cache[i]);
        lock_release(&cache[i].lock);
    }
}