#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <hash.h>
#include <list.h>
#include "threads/synch.h"
#include "vm/page.h"
#include "threads/palloc.h"
#include "userprog/pagedir.h"
#include "threads/thread.h"
#include "filesys/file.h"
#include "vm/swap.h"

struct list lru_list;
struct lock lru_list_lock;
struct list_elem *lru_clock;


void lru_list_init(void);
void add_lru_list(struct page* page);
void del_lru_list(struct page *page);

void free_victim_pages(enum palloc_flags flags UNUSED);

struct page *alloc_page(enum palloc_flags flags);
void find_and_free_page(void *kaddr);
void free_page(struct page *page);

#endif
